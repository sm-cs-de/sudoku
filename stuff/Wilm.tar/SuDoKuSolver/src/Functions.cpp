/***************************************************************************
 *   Copyright (C) 2008 by repogu   *
 *   repogu@ubuntu   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "Functions.h"

void printPre()
{
cout<<endl;
cout<<endl;
cout<<"Welcome to the SuDoKuSolver."<<endl;
cout<<endl;
cout<<"This programm solves from you a given"<<endl;
cout<<"Sudoku riddle."<<endl;




};


void printHelp()
{
cout<<endl;
cout<<endl;
cout<<"Synopsis: sudokusolver <filename>"<<endl;
cout<<endl;
cout<<"You have to make a file with your riddle"<<endl;
cout<<"so SuDoKuSolver can sove it for you."<<endl;
cout<<"However, this programm provides you EVERY possible solution"<<endl;
cout<<"Unknown numbers are represented by a '0'."<<endl;
cout<<endl;
cout<<"Expample"<<endl;
cout<<endl;
cout<<"testfile:"<<endl;
cout<<"0 1 0 7 6 0 9 0 0"<<endl;
cout<<"0 0 7 0 0 3 0 2 0"<<endl;
cout<<"6 8 0 0 2 0 0 0 0"<<endl;
cout<<"0 2 0 8 0 5 0 0 9"<<endl;
cout<<"8 0 5 0 0 0 2 0 1"<<endl;
cout<<"9 0 0 2 0 1 0 4 0"<<endl;
cout<<"0 0 0 0 8 0 0 9 2"<<endl;
cout<<"0 4 0 9 0 0 7 0 0"<<endl;
cout<<"0 0 9 0 4 2 0 8 0"<<endl;
cout<<endl;
cout<<"sudokusolver testfile"<<endl;
cout<<"will print the riddle and the solution"<<endl;
cout<<endl;

};
