/***************************************************************************
 *   Copyright (C) 2008 by repogu   *
 *   repogu@ubuntu   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "field.h"

Field::Field()
{



}


Field::~Field()
{


}

/*!
    \fn Field::operator[](int i, int j)
 */
Box Field::GetBox(int i, int j)
{

if( !(i<10 && i>0 && j<10 && j>0 ) )
{ return Box(); }
else
{ return Data[i][j]; };

}

/*!
    \fn Field::ReadFromFile( string Filename )
 */
bool Field::ReadFromFile( string Filename )
{

cout<<"Read riddle from file"<<endl;

ifstream ifs;

ifs.open(Filename.c_str())  ;

if( !ifs )
{ return false; }

int i=0;
int j=0;

int number=0;

Box buffer;

for(i=0;i<9;i++)
{


	for(j=0;j<9;j++)
	{
	if( ifs.eof() ){ return false; };
	
	ifs>>number;

	(Data[i][j]).SetNumberInsecure( number );

	};

};

return true;

}



/*!
    \fn Field::printfull()
 */
void Field::printfull()
{
int i=0;
int j=0;

for(  i=0;i<9;i++)
{
	for(j=0;j<9;j++)
	{
	(Data[i][j]).printfull();
	cout<<"\t";

	};
cout<<endl;
};
}


/*!
    \fn Field::print()
 */
void Field::print()
{

int i=0;
int j=0;

for(  i=0;i<9;i++)
{
	for(j=0;j<9;j++)
	{
	(Data[i][j]).print();
	cout<<"\t";

	};
cout<<endl;
};

}


/*!
    \fn Field::GetParts()
 */
vector<   vector<Box*> > Field::GetParts()
{



int i=0;
int j=0;

vector<  vector<Box*> > out(27);

for(i=0;i<27;i++)
{
out.at(i)=vector< Box* >(9);
};


//at first the lines
for(i=0;i<9;i++)
{

	for(j=0;j<9;j++)
	{
	(  out.at(i)  ).at(j)=&(Data[i][j]);

	};

};


//then the rows
for(i=0;i<9;i++)
{

	for(j=0;j<9;j++)
	{
	(  out.at(9+i)  ).at(j)=&(Data[j][i]);

	};
};

//and now the little squares

int bigi=0;
int bigj=0;

for(bigi=0;bigi<3;bigi++)
{
	for(bigj=0;bigj<3;bigj++)
	{

		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
			{

(out.at(18+bigi*3+bigj) ).at(i*3+j)=  &(Data[bigi*3+ i  ][bigj*3+ j ]) ;
			
			};
		};
	
	

	
	};

};

return out;

}





/*!
    \fn Field::DeleteKnownPossibleInLine( Box** )
 */
bool Field::DeleteKnownPossibleInLine( vector<Box*> in)
{

int i=0;
int j=0;


vector<int> buffvec(0);

for( i=0;i<9;i++ )
{
if( (in[i])->GetNumber()!=0 ){ buffvec.push_back( (in[i])->GetNumber() ); };
};

bool out =false;

for( i=0;i<in.size();i++ )
{

if(  (in[i])->DeleteFromPossible( buffvec )  )
{ out=true; };


};

return out;

}



/*!
    \fn Field::CleanPossible()
 */
void Field::CleanPossible()
{

vector<  vector<Box*> > Parts=GetParts();


int i=0;

	for(i=0;i<Parts.size();i++)
	{
	DeleteKnownPossibleInLine( Parts[i] );
	
	};

}



/*!
    \fn Field::FillNativ()
 */
bool Field::FillNativ()
{
vector< vector<Box*> > Parts=GetParts();


int i=0;
int j=0;

bool out=false;

	for(i=0;i<Parts.size();i++)
	{
		for(j=0;j<(Parts[i]).size();j++)
		{
		if(   (Parts[i])[j]->TrySetNativ()    )
		{ out=true; };
		}
	};

return out;

}




/*!
    \fn Field::Fill()
 */
bool Field::Fill()
{
bool out=false;

if( FillNativ() )
{ out=true; };

CleanPossible(  );

if( FillSingularPossible() )
{ out=true; };

return out;

}



/*!
    \fn Field::Solve()
 */
bool Field::Solve()
{


bool check=false;

do
{

CleanPossible();

if( Fill() )
{ check=true; }
else
{ check=false; };


if( !ConsistencyCheck() )
{  return false ; };

}while( check );



if( CheckStatus() )
{ cout<<endl<<"One solution is:"<<endl  ;printfull() ; return true; };

Field Tester;
Tester=*this;


int n=0;
int m=0;

Tester.GetGuess(n,m);


int i=0;

bool out=false;

vector<int> AllPossible=(Tester.Data[n][m]).GetPossible();

for(i=0;i<AllPossible.size()  ;i++)
{


Tester=*this;

(Tester.Data[n][m]).SetNumber(  AllPossible.at(i)  );


if(Tester.Solve() )
{out=true;};


};


return out;


}





/*!
    \fn Field::ConsistencyCheck()
 */
bool Field::ConsistencyCheck()
{



int i=0;
int j=0;

for(i=0;i<9;i++)
{
	for(j=0;j<9;j++)
	{
	if(  ! (  (Data[i][j]).ConsistencyCheck()  ) ){ return false; };
	};
};

vector<  vector<Box*> > Parts=GetParts();

vector< vector<int>  > hist;

for(i=0;i<Parts.size();i++)
{
hist=MakeHistogramm( Parts[i]);



	for(j=1;j<hist.size();j++)
	{

	if( ((hist.at(j)).at(1))>1 ) {return(false);}; 

	};


};


return true;

}


/*!
    \fn Field::MakeHistogramm( vector<Box*> )
 */
vector< vector<int>  > Field::MakeHistogramm( vector<Box*> in)
{

int i=0;

vector< vector<int> > out( 10 );

	for(i=0;i<10;i++)
	{  
	out.at(i)=vector<int>(2);  
	(out.at(i)).at(0)=i;
	(out.at(i)).at(1)=0;	
	};

	for(i=0;i<in.size();i++)
	{
		(out[(in[i])->GetNumber()]).at(1)++;
	};

return out;

}



/*!
    \fn Field::MakePossibleHistogramm( vector< Box* > )
 */
vector< vector<int> > Field::MakePossibleHistogramm( vector< Box* > in)
{

int i=0;
int j=0;

vector< vector<int> > out( 10 );

	for(i=0;i<10;i++)
	{  
	out.at(i)=vector<int>(0);  
	};

vector < int > buffer(0);

for(i=0;i<in.size();i++)
{


	buffer=in.at(i)->GetPossible();

		for(j=0;j<buffer.size();j++)
		{
		out.at( buffer.at(j) ).push_back( i );
		};


};

for(i=0;i<out.size();i++)
{ 
sort( out.at(i).begin(),out.at(i).end() );  
};


return out;

}


/*!
    \fn Field::FillSingularPossible()
 */
bool Field::FillSingularPossible()
{

vector<   vector<Box*> > Parts=GetParts();

int i=0;
int j=0;
int k=0;

vector<  vector<int> > buffer;

vector< Box* > ToSet(0);
vector<  int > ToSetNumbers(0);



for(i=0;i<Parts.size();i++)
{
buffer=MakePossibleHistogramm( Parts.at(i) );

	for(j=1;j<buffer.size();j++)
	{
//Attention. One NOT can set this on the fly
//on had to Clean at first the Set, but I want to seperate the filling and the
//cleaning......
//perhaps that's not clever..... but I won't argue with you, ass face 
		if( buffer.at(j).size()==1 )
		{ 
		ToSetNumbers.push_back( j );
		ToSet.push_back( (Parts.at(i) ).at( (buffer.at(j)).at(0) ) );

		};


		
	};



};


bool out=false;

//now we set them
 for(i=0; i<ToSetNumbers.size() ; i++)
 {
ToSet.at(i)->SetNumber( ToSetNumbers.at(i) );
out=true;
 };

return out;

}




/*!
    \fn Field::CheckStatus()
 */
bool Field::CheckStatus()
{
int i=0;
int j=0;

for(i=0;i<9;i++)
{

	for(j=0;j<9;j++)
	{
	if( Data[i][j].GetNumber() ==0 )
	{ return false; };
	
	};

};


return true;

}




/*!
    \fn Field::GetGuess(int& i, int& j, int& Number)
 */
bool Field::GetGuess(int& i, int& j)
{


for(i=0;i<9;i++)
{

	for(j=0;j<9;j++)
	{
	if( Data[i][j].GetNumber()==0 )
	{ return true; };

	};

return false;

};

}
