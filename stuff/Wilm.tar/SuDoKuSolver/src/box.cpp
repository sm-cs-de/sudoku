/***************************************************************************
 *   Copyright (C) 2008 by repogu   *
 *   repogu@ubuntu   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "box.h"

Box::Box()
{
Number=0;

PossibleNumbers=vector<int>(9);

int i=0;

for(i=1;i<10;i++)
{

PossibleNumbers.at(i-1)=i;

};

}


Box::~Box()
{

//nothing to do

}


/*!
    \fn Box::DeleteFromPossible( int n )
 */
bool Box::DeleteFromPossible( int n )
{
int i=0;

vector<int> newer(0);

for(i=0;i<PossibleNumbers.size();i++)
	{
	
	if( PossibleNumbers.at(i)!=n )
	{ newer.push_back( PossibleNumbers.at(i) ); };
	
	};

if(  PossibleNumbers.size()!=newer.size() )
{PossibleNumbers=newer ; return true; }
else
{ return false; };

}


/*!
    \fn Box::IfSet()
 */
bool Box::IfSet()
{
if(  Number==0 )
{  return false; }
else
{ return true; };
}


/*!
    \fn Box::GetNumber()
 */
int Box::GetNumber()
{
return Number;
}


/*!
    \fn Box::TrySetNativ()
 */
bool Box::TrySetNativ()
{
if ( PossibleNumbers.size()==1 )
{ 
	Number=PossibleNumbers.at(0);
	PossibleNumbers=vector<int>(0);
	return true;
}
else
{ return false; }

}


/*!
    \fn Box::DeleteFromPossible( vector<int> vecn )
 */
bool Box::DeleteFromPossible( vector<int> vecn )
{

int i=0;

bool out=false;

	for( i=0;i<vecn.size();i++ )
	{
	if(  DeleteFromPossible( vecn.at(i) ) )
	{ out =true; };
	
	};

return out;

}


/*!
    \fn Box::SetNumber( int ToSet )
 */
bool Box::SetNumber( int ToSet )
{

if( !CheckPossible(ToSet) )
{ return false; };

Number=ToSet;
PossibleNumbers=vector<int>(0);

return true;

}


/*!
    \fn Box::GetPossible()
 */
vector<int> Box::GetPossible()
{
return PossibleNumbers;
}

/*!
    \fn Box::CheckPossible(int n)
 */
bool Box::CheckPossible(int n)
{



int i=0;

	for(i=0;i<PossibleNumbers.size();i++)
	{
		if( PossibleNumbers.at(i)==n )
		{ return true; };
	};


return false;



}



/*!
    \fn Box::SetNumberInsecure()
 */
bool Box::SetNumberInsecure(int n)
{

Number=n;

if( n!=0 )PossibleNumbers=vector<int>(0);

if( Number<0 || Number>9 )
{ return false; }
else
{ return true; }

}


/*!
    \fn Box::printfull()
 */
void Box::printfull()
{
cout<<Number;

cout<<"(";

int i=0;

for(i=0;i<PossibleNumbers.size();i++)
{
cout<<PossibleNumbers.at(i);
};

cout<<")";

return ;

}





/*!
    \fn Box::print()
 */
void Box::print()
{
cout<<Number;
}



/*!
    \fn Box::ConsistencyCheck()
 */
bool Box::ConsistencyCheck()
{


if( Number==0 && PossibleNumbers.size()==0 )
{ return false; }
else
{ return true; };


}

